package main

import (
	"context"
	"errors"
	"fmt"
	"net/http"

	"github.com/ydb-platform/ydb-go-sdk/v3/query"
)

// Sender получает метрики и формирует Body респонса
func Sender(ctx context.Context) (*Response, error) {
	metras := GetRuntimeMetric()
	outer := ""

	for metr, value := range metras {
		outer += fmt.Sprintf("%20s\t\t%g\n", metr, value)
	}
	fmt.Print("Serverless works NOW !!!")
	return &Response{
		StatusCode: 200,
		Body:       outer,
	}, nil
}

// putMetrics запись одной метрики в базу данных
func PutMetric(ctx context.Context, event *APIGatewayRequest) (*Response, error) {
	// формат URL - <apiURL>/update/<mname>/<mvalue>
	operationContext := event.RequestContext.APIGateway.OperationContext

	mname, ok1 := operationContext["mname"]
	mvalue, ok2 := operationContext["mvalue"]
	if !ok1 || !ok2 {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       `{"status":"bad parameters, should be /update/<mname>/<mvalue>"}`,
		}, errors.New("bad paramaters")
	}

	db, err := ConnectToBase(ctx)
	if err != nil {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       `{"status":"DataBase Service Unavailable"}`,
		}, err
	}
	defer db.Close(ctx)
	order := fmt.Sprintf("UPSERT INTO metrics (metricname, value, updated_at) VALUES ('%s', %s, CurrentUtcDatetime() ) ;", mname, mvalue)

	err = db.Query().Exec(ctx, order, query.WithTxControl(query.NoTx()))
	if err != nil {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       `{"status":"metric was not written to DB"}`,
		}, err
	}

	return &Response{
		StatusCode: 200,
		Body:       fmt.Sprintf("Ok put metric %s value %s", mname, mvalue),
	}, nil
}

func GetOneMetric(ctx context.Context, event *APIGatewayRequest) (*Response, error) {
	// формат URL - <apiURL>/update/<mname>/<mvalue>
	operationContext := event.RequestContext.APIGateway.OperationContext

	mname, ok := operationContext["mname"]
	if !ok {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       `{"status":"bad parameters, should be /update/<mname>/<mvalue>"}`,
		}, errors.New("bad paramaters")
	}

	db, err := ConnectToBase(ctx)
	if err != nil {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       `{"status":"DataBase Service Unavailable"}`,
		}, err
	}
	defer db.Close(ctx)

	order := fmt.Sprintf("SELECT value FROM metrics WHERE metricname='%s'; ", mname)
	row, err := db.Query().QueryRow(ctx, order, query.WithTxControl(query.NoTx()))
	if err != nil {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       fmt.Sprintf("BAD scan metric %s ", mname),
		}, err
	}

	var val float64
	err = row.Scan(&val)
	if err != nil {
		return &Response{
			StatusCode: http.StatusServiceUnavailable, // 503
			Body:       fmt.Sprintf("BAD get metric %s value %g", mname, val),
		}, err
	}
	return &Response{
		StatusCode: http.StatusServiceUnavailable, // 503
		Body:       fmt.Sprintf("Ok get metric %s value %g", mname, val),
	}, err

}
